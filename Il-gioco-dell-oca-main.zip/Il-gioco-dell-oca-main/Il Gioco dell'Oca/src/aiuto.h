#ifndef AIUTO_H_
#define AIUTO_H_

void chiedere_aiuto (int * sale);

#endif /* AIUTO_H_ */