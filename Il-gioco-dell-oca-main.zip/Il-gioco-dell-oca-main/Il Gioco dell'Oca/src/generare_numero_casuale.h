//
// Created by Potito Florio on 09/06/2023.
//

#ifndef GENERARE_NUMERO_CASUALE_H
#define GENERARE_NUMERO_CASUALE_H



int generare_numero (int numero_massimo, int numero_minimo, int sale);



#endif //GENERARE_NUMERO_CASUALE_H
